package test;
public class Tuition 
{
	private double result;
	private String semester;
	private boolean online;
	public double undergraduate(String semester, boolean online)
	{
		if(semester.equals("Winter"))
		{
			return onlineWinterUnder(online);
		}
		else
			return result = 1400;
	}
	private double onlineWinterUnder(boolean online) 
	{
		if(online)
			return result = 1500;
		else
			return result = 1250;
	}
	public double postgraduate(String semester, boolean online)
	{
		if(semester.equals("Summer"))
		{
			return unonlineSummerPost(online);
		}
		else
		{
			return unonlineWinterPost(online);
		}
	}
	private double unonlineSummerPost(boolean online)
	{
		if(!online)
			return result = 2500;
		else 
	    	return result = 1800;
	}
	private double unonlineWinterPost(boolean online)
	{
		if(!online)
			return result = 2200;
		else 
	    	return result = 1600;
	}
	public double psd(String semester, boolean online)
	{
		return result = 3000;
	}
}