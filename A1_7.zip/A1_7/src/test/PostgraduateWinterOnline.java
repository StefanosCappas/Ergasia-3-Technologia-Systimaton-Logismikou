package test;
public class PostgraduateWinterOnline extends Postgraduate
{
	public double getTuitionFees()
	{
		return 1600;
	}
}