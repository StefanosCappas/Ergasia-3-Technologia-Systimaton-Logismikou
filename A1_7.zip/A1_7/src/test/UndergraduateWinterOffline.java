package test;
public class UndergraduateWinterOffline extends Undergraduate
{
	public double getTuitionFees()
	{
		return 1250;
	}
}