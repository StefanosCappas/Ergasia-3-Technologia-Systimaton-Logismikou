package test;
public abstract class Postgraduate extends Tuition
{
}