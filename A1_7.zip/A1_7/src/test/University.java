package test;
public class University 
{	
	public static final int UNDERGRAD = 0;
	public static final int GRADUATE = 1;
	public static final int PHD = 2;	
	private int type;
	private String semester;
	private boolean online;
	UndergraduateWinterOnline u1 = new UndergraduateWinterOnline();
	UndergraduateWinterOffline u2 = new UndergraduateWinterOffline();
	UndergraduateSummer u3 = new UndergraduateSummer();
	PostgraduateSummerOffline p1 = new PostgraduateSummerOffline();
	PostgraduateSummerOnline p2 = new PostgraduateSummerOnline();
	PostgraduateWinterOffline p3 = new PostgraduateWinterOffline();
	PostgraduateWinterOnline p4 = new PostgraduateWinterOnline(); 
	public void setType(int type, String semester, boolean online) 
	{
		this.type = type;
		this.semester = semester;
		this.online = online;
	}	
	public void getTuitionFees() 
	{
		if(type == University.UNDERGRAD) 
		{
			if (semester == "Winter")
			{
				if (online)
					System.out.println(u1.getTuitionFees());
				else
					System.out.println(u2.getTuitionFees());
			}
			u3.getTuitionFees();
		}
		else if(type == University.GRADUATE) 
		{
			if (semester == "Summer")
			{
				if (!online)
					System.out.println(p1.getTuitionFees());
				else
					System.out.println(p2.getTuitionFees());
			}
			else
			{
				if (!online)
					System.out.println(p3.getTuitionFees());
				else
					System.out.println(p4.getTuitionFees());
			}
		}
		else if(type == University.PHD)
		{
			PHD phd = new PHD();
			System.out.println(phd.getTuitionFees());
		}
	}
}