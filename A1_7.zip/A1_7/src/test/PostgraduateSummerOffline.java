package test;
public class PostgraduateSummerOffline extends Postgraduate
{
	public double getTuitionFees()
	{
		return 2500;
	}
}