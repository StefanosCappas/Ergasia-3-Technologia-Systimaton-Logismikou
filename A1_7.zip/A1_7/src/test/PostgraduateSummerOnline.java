package test;
public class PostgraduateSummerOnline extends Postgraduate
{
	public double getTuitionFees()
	{
		return 1800;
	}
}