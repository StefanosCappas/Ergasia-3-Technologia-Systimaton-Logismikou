package test;
public abstract class Tuition 
{
	public abstract double getTuitionFees();
}