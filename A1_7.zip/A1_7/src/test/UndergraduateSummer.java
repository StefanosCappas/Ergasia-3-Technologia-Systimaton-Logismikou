package test;
public class UndergraduateSummer extends Undergraduate
{
	public double getTuitionFees()
	{
		return 1400;
	}
}