package test;
import java.util.ArrayList;
public class University 
{	
	ArrayList<Tuition> aList = new ArrayList();
	public void setType(Tuition t) 
	{
		aList.add(t);
	}	
	public void printTuitionFees() 
	{
		for (int i = 0; i < aList.size(); i++)
			System.out.println(aList.get(i).getTuitionFees());
	}
}