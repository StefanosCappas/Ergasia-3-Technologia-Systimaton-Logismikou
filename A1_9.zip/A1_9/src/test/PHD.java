package test;
public class PHD extends Tuition
{
	public double getTuitionFees() 
	{
		return 3000;
	}
}