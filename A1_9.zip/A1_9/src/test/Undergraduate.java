package test;
public abstract class Undergraduate extends Tuition
{
}