package test;
public class PostgraduateWinterOffline extends Postgraduate
{
	public double getTuitionFees()
	{
		return 2200;
	}
}