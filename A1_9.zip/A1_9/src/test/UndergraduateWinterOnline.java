package test;
public class UndergraduateWinterOnline extends Undergraduate
{
	public double getTuitionFees()
	{
		return 1500;
	}
}