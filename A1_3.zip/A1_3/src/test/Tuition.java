package test;
public class Tuition 
{
	private double result;
	private String semester;
	private boolean online;
	UnOnlineSemesterGraduate un = new UnOnlineSemesterGraduate();
	public double undergraduate(String semester, boolean online)
	{
		if(semester.equals("Winter"))
			return un.onlineWinterUnder(online);
		else
			return result = 1400;
	}

	public double postgraduate(String semester, boolean online)
	{
		if(semester.equals("Summer"))
			return un.unonlineSummerPost(online);
		else
			return un.unonlineWinterPost(online);
	}

	public double psd(String semester, boolean online)
	{
		return result = 3000;
	}
}