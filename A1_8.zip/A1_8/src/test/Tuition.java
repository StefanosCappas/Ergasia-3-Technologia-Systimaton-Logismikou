package test;
public abstract class Tuition 
{
	public abstract double getTuitionFees();
	public void printTuitionFees()
	{
		System.out.println(getTuitionFees());
	}
}