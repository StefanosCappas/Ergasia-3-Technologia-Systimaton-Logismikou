package test;
public class Main 
{
	public static void main(String[] args) 
	{	
		University uni = new University();	
		uni.setType(new UndergraduateWinterOnline());
		uni.setType(new UndergraduateWinterOffline());
		uni.setType(new UndergraduateSummer());
		uni.setType(new PostgraduateSummerOffline());
		uni.setType(new PostgraduateSummerOnline());
		uni.setType(new PostgraduateWinterOffline());
		uni.setType(new PostgraduateWinterOnline());
		uni.setType(new PHD());
		uni.printTuitionFees();
	}
}