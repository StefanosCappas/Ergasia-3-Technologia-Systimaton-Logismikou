package test;
public class University 
{	
	public static final int UNDERGRAD = 0;
	public static final int GRADUATE = 1;
	public static final int PHD = 2;	
	private int type;
	public void setType(int x) 
	{
		type = x;
	}
	private String semester = "Winter";
	private boolean online = true;
	public double getTuitionFees() 
	{
		double result = 0;
		if(type == University.UNDERGRAD) 
		{
			if(semester.equals("Winter"))
			{
				if(online)
					result = 1500;
				else
					result = 1250;
			}
			else
				result = 1400;
		}
		else if(type == University.GRADUATE) 
		{
			if(semester.equals("Summer"))
			{
				if(!online)
					result = 2500;
			    else 
			    	result = 1800;
			}
			else
			{
				if(!online)
					result = 2200;
				else 
					result = 1600;
			}
		}
		else if(type == University.PHD)
		{
			result = 3000;
		}
		return result;
	}
}