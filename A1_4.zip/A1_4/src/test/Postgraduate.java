package test;
public class Postgraduate extends Tuition
{
	public double postgraduate(String semester, boolean online)
	{
		if(semester.equals("Summer"))
			return un.unonlineSummerPost(online);
		else
			return un.unonlineWinterPost(online);
	}
}