package test;
public abstract class Tuition 
{
	protected double result;
	protected String semester;
	protected boolean online;
	UnOnlineSemesterGraduate un = new UnOnlineSemesterGraduate();
}