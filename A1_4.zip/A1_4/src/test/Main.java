package test;
public class Main 
{
	public static void main(String[] args) 
	{	
		University uni = new University();	
		uni.setType(1);
		System.out.println(uni.getTuitionFees());
	}
}