package test;
public class University 
{	
	public static final int UNDERGRAD = 0;
	public static final int GRADUATE = 1;
	public static final int PHD = 2;	
	private int type;
	public void setType(int x) 
	{
		type = x;
	}	
	private String semester = "Winter";
	private boolean online = true;
	public double getTuitionFees() 
	{
		double result = 0;
		if(type == University.UNDERGRAD) 
		{
			Undergraduate u = new Undergraduate();
			result = u.undergraduate(semester, online);
		}
		else if(type == University.GRADUATE) 
		{
			Postgraduate p = new Postgraduate();
			result = p.postgraduate(semester, online);
		}
		else if(type == University.PHD)
		{
			PHD phd = new PHD();
			result = phd.psd(semester, online);
		}
		return result;
	}
}