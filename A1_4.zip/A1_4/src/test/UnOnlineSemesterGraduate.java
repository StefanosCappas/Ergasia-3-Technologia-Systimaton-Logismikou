package test;
public class UnOnlineSemesterGraduate 
{
	private double result;
	public double onlineWinterUnder(boolean online) 
	{
		if(online)
			return result = 1500;
		else
			return result = 1250;
	}
	public double unonlineSummerPost(boolean online)
	{
		if(!online)
			return result = 2500;
		else 
	    	return result = 1800;
	}
	public double unonlineWinterPost(boolean online)
	{
		if(!online)
			return result = 2200;
		else 
	    	return result = 1600;
	}
}