package test;
public class Undergraduate extends Tuition
{
	public double undergraduate(String semester, boolean online)
	{
		if(semester.equals("Winter"))
			return un.onlineWinterUnder(online);
		else
			return result = 1400;
	}
}