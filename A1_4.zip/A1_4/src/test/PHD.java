package test;
public class PHD extends Tuition
{
	public double psd(String semester, boolean online)
	{
		return result = 3000;
	}
}