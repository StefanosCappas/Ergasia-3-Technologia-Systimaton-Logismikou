package test;
public class Undergraduate extends Tuition
{
	public double undergraduate(String semester, boolean online)
	{
		if(semester.equals("Winter"))
		{
			if(online)
				return result = 1500;
			else
				return result = 1250;
		}
		else
			return result = 1400;
	}
}