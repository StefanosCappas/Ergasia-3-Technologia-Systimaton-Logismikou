package test;
public class Tuition 
{
	private double result;
	private String semester;
	private boolean online;
	public double undergraduate(String semester, boolean online)
	{
		if(semester.equals("Winter"))
		{
			if(online)
				return result = 1500;
			else
		    	return result = 1250;
		}
		else
			return result = 1400;
	}
	public double postgraduate(String semester, boolean online)
	{
		if(semester.equals("Summer"))
		{
			if(!online)
				return result = 2500;
			else 
		    	return result = 1800;
		}
		else
		{
			if(!online)
				return result = 2200;
			else 
		    	return result = 1600;
		}
	}
	public double psd(String semester, boolean online)
	{
		return result = 3000;
	}
}