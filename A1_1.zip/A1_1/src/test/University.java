package test;
public class University 
{	
	public static final int UNDERGRAD = 0;
	public static final int GRADUATE = 1;
	public static final int PHD = 2;	
	private int type;
	public void setType(int x) 
	{
		type = x;
	}
	Tuition t = new Tuition();
	private String semester = "Winter";
	private boolean online = true;
	public double getTuitionFees() 
	{
		double result = 0;
		if(type == University.UNDERGRAD) 
		{
			result = t.undergraduate(semester, online);
		}
		else if(type == University.GRADUATE) 
		{
			result = t.postgraduate(semester, online);
		}
		else if(type == University.PHD)
		{
			result = t.psd(semester, online);
		}
		return result;
	}
}